import React from 'react'
import "./Copyrightcomp.css"
const Copyrightcomp = () => {
  return (
    <div id='Copyright-comp'>
      <div id='copy-content'>2021 ©  Laundry</div>
    </div>
  )
}

export default Copyrightcomp