import React from 'react'
import "./Refercomp.css"
const Refercomp = () => {
  return (
    <div id='Refer-comp'>
      <div id='top-line'></div>
      <div id='referral-content'>Now Refer & Earn ₹500 for every referral*</div>
      <div id="terms">* Terms and conditions will be applied</div></div>
  )
}

export default Refercomp