import React from "react";
import "./footerP2.css"

const FooterSecond =()=>{
    return(
        <>
        <footer id="footer">
        <p className="footer_para"> 2022 <p className="circle">C</p> Laundry</p>
        </footer>
        </>
    )
}

export default FooterSecond;